import streamlit as st
from PIL import Image
import torch
import numpy as np

# Water footprint database
water_footprint_db = {
    'Rice': 2500,  # liters per kg
    'Corn': 1500,  # liters per kg
    'Soybean': 2000,  # liters per kg
    'Wheat': 1800,  # liters per kg
    'Tomato': 560,  # liters per kg
    'Cucumber': 800,  # liters per kg
    'Potato': 500,  # liters per kg
    'Onion': 600,  # liters per kg
    'Bottled Orange Juice': 2000,  # liters per liter
    'Cooked Rice': 2500,  # liters per kg
    'Steamed Tomato': 560,  # liters per kg
    'Canned Beans': 1200,  # liters per kg
}

class_names = [
    'Rice', 'Corn', 'Soybean', 'Wheat', 'Tomato', 'Cucumber', 'Potato', 'Onion',
    'Bottled Orange Juice', 'Cooked Rice', 'Steamed Tomato', 'Canned Beans'
]

# Translations for multi-language support
translations = {
    'English': {
        'app_title': 'Water Footprint Calculator',
        'app_description': 'The Water Footprint Calculator helps you estimate the water footprint for various agricultural and final products.',
        'features': 'Features:\n- Calculate Water Footprint for Raw Products: Input crop type and quantity.\n- Calculate Water Footprint for Final Products: Input the final product and quantity.\n- Detect Fruits/Vegetables from Image: Upload an image to identify the fruit or vegetable.',
        'calculate_raw_products': 'Calculate Water Footprint for Raw Products: Wheat, Rice, Corn, Soybean',
        'calculate_final_products': 'Calculate Water Footprint for Final Products: Bottled Orange Juice, Cooked Rice, Steamed Tomato, Canned Beans',
        'detect_image': 'Detect Fruits/Vegetables from Image',
        'supported_products': 'Supported Products:\nRaw Products: Wheat, Rice, Corn, Soybean\nFinal Products: Bottled Orange Juice, Cooked Rice, Steamed Tomato, Canned Beans',
        'how_to_use': 'How to Use:\n1. Select Product Type: Raw or Final.\n2. Choose Input Method: Image or Manual.\n3. Upload an Image (if selected) or Input Product Name.\n4. Click Calculate.',
        'developed_by': 'Developed by BitByBit',
        'upload_image': 'Upload Image',
        'enter_product': 'Enter Product Name',
        'enter_quantity': 'Enter Quantity (kg)',
        'calculate_button': 'Calculate',
        'water_footprint': 'Water Footprint for {} kg of {}: {} liters',
        'not_found': 'Product not found in database. Please enter a valid product.',
        'select_language': 'Select Language'
    },
    'Hindi': {
        'app_title': 'वॉटर फुटप्रिंट कैलकुलेटर',
        'app_description': 'वॉटर फुटप्रिंट कैलकुलेटर आपको विभिन्न कृषि और अंतिम उत्पादों के लिए पानी के फुटप्रिंट का अनुमान लगाने में मदद करता है।',
        'features': 'विशेषताएँ:\n- कच्चे उत्पादों के लिए पानी का फुटप्रिंट कैलकुलेट करें: फसल का प्रकार और मात्रा दर्ज करें।\n- अंतिम उत्पादों के लिए पानी का फुटप्रिंट कैलकुलेट करें: अंतिम उत्पाद और मात्रा दर्ज करें।\n- छवि से फल/सब्जियाँ पहचानें: छवि अपलोड करें ताकि फल या सब्जी की पहचान की जा सके।',
        'calculate_raw_products': 'कच्चे उत्पादों के लिए पानी का फुटप्रिंट कैलकुलेट करें: गेहूं, चावल, मकई, सोयाबीन',
        'calculate_final_products': 'अंतिम उत्पादों के लिए पानी का फुटप्रिंट कैलकुलेट करें: बोतलबंद संतरे का रस, पका हुआ चावल, स्टीम्ड टमाटर, कैन किया हुआ बीन्स',
        'detect_image': 'छवि से फल/सब्जियाँ पहचानें',
        'supported_products': 'समर्थित उत्पाद:\nकच्चे उत्पाद: गेहूं, चावल, मकई, सोयाबीन\nअंतिम उत्पाद: बोतलबंद संतरे का रस, पका हुआ चावल, स्टीम्ड टमाटर, कैन किया हुआ बीन्स',
        'how_to_use': 'उपयोग करने का तरीका:\n1. उत्पाद प्रकार चुनें: कच्चा या अंतिम।\n2. इनपुट विधि चुनें: छवि या मैनुअल।\n3. छवि अपलोड करें (यदि चयनित) या उत्पाद का नाम दर्ज करें।\n4. गणना पर क्लिक करें।',
        'developed_by': 'BitByBit द्वारा विकसित',
        'upload_image': 'छवि अपलोड करें',
        'enter_product': 'उत्पाद का नाम दर्ज करें',
        'enter_quantity': 'मात्रा दर्ज करें (किलोग्राम)',
        'calculate_button': 'गणना करें',
        'water_footprint': '{} किलोग्राम {} के लिए पानी का फुटप्रिंट: {} लीटर',
        'not_found': 'डेटाबेस में उत्पाद नहीं मिला। कृपया एक वैध उत्पाद दर्ज करें।',
        'select_language': 'भाषा चुनें'
    },
    'Kannada': {
        'app_title': 'ನೀರು ಪಾದಚಾರಕ ಕ್ಯಾಲ್ಕುಲೆಟರ್',
        'app_description': 'ನೀರು ಪಾದಚಾರಕ ಕ್ಯಾಲ್ಕುಲೆಟರ್ ನಿಮಗೆ ವಿವಿಧ ಕೃಷಿ ಮತ್ತು ಅಂತಿಮ ಉತ್ಪನ್ನಗಳಿಗೆ ನೀರಿನ ಪಾದಚಾರಕವನ್ನು ಅಂದಾಜಿಸಲು ಸಹಾಯ ಮಾಡುತ್ತದೆ.',
        'features': 'ಲಕ್ಷಣಗಳು:\n- ಕಚ್ಚಾ ಉತ್ಪನ್ನಗಳಿಗೆ ನೀರಿನ ಪಾದಚಾರಕವನ್ನು ಲೆಕ್ಕಹಾಕಿ: ಬೆಳೆದ ಪ್ರಕಾರ ಮತ್ತು ಪ್ರಮಾಣವನ್ನು ನಮೂದಿಸಿ.\n- ಅಂತಿಮ ಉತ್ಪನ್ನಗಳಿಗೆ ನೀರಿನ ಪಾದಚಾರಕವನ್ನು ಲೆಕ್ಕಹಾಕಿ: ಅಂತಿಮ ಉತ್ಪನ್ನ ಮತ್ತು ಪ್ರಮಾಣವನ್ನು ನಮೂದಿಸಿ.\n- ಚಿತ್ರದಿಂದ ಹಣ್ಣು/ತರಕಾರಿಗಳನ್ನು ಗುರುತಿಸಿ: ಹಣ್ಣು ಅಥವಾ ತರಕಾರಿ ಗುರುತಿಸಲು ಚಿತ್ರವನ್ನು ಅಪ್ಲೋಡ್ ಮಾಡಿ.',
        'calculate_raw_products': 'ಕಚ್ಚಾ ಉತ್ಪನ್ನಗಳಿಗೆ ನೀರಿನ ಪಾದಚಾರಕವನ್ನು ಲೆಕ್ಕಹಾಕಿ: ಗೋಧಿ, ಅಕ್ಕಿ, ಜೋಳ, ಸೋಯಾ ಬೀನ್',
        'calculate_final_products': 'ಅಂತಿಮ ಉತ್ಪನ್ನಗಳಿಗೆ ನೀರಿನ ಪಾದಚಾರಕವನ್ನು ಲೆಕ್ಕಹಾಕಿ: ಬಾಟ್ಲ್ ಮಾಡಿದ ಕಿತ್ತಳೆ ಜ್ಯೂಸ್, ಪಾಕವಾದ ಅಕ್ಕಿ, ಸ್ಟೀಮ್ ಮಾಡಿದ ಟೊಮಟೋ, ಕ್ಯಾನ್ಡ್ ಬೀನ್‌ಗಳು',
        'detect_image': 'ಚಿತ್ರದಿಂದ ಹಣ್ಣು/ತರಕಾರಿಗಳನ್ನು ಗುರುತಿಸಿ',
        'supported_products': 'ಮಟ್ಟಿಗೆ ಮಾಡಲಾದ ಉತ್ಪನ್ನಗಳು:\nಕಚ್ಚಾ ಉತ್ಪನ್ನಗಳು: ಗೋಧಿ, ಅಕ್ಕಿ, ಜೋಳ, ಸೋಯಾ ಬೀನ್‌ಗಳು\nಅಂತಿಮ ಉತ್ಪನ್ನಗಳು: ಬಾಟ್ಲ್ ಮಾಡಿದ ಕಿತ್ತಳೆ ಜ್ಯೂಸ್, ಪಾಕವಾದ ಅಕ್ಕಿ, ಸ್ಟೀಮ್ ಮಾಡಿದ ಟೊಮಟೋ, ಕ್ಯಾನ್ಡ್ ಬೀನ್‌ಗಳು',
        'how_to_use': 'ಬಳಸಲು ಹೇಗೆ:\n1. ಉತ್ಪನ್ನದ ಪ್ರಕಾರ ಆಯ್ಕೆ ಮಾಡಿ: ಕಚ್ಚಾ ಅಥವಾ ಅಂತಿಮ.\n2. ಇನ್ಪುಟ್ ವಿಧಾನವನ್ನು ಆಯ್ಕೆ ಮಾಡಿ: ಚಿತ್ರ ಅಥವಾ ಮ್ಯಾನುಯಲ್.\n3. ಚಿತ್ರವನ್ನು ಅಪ್ಲೋಡ್ ಮಾಡಿ (ಆಪ್ಷನಲ್) ಅಥವಾ ಉತ್ಪನ್ನದ ಹೆಸರನ್ನು ನಮೂದಿಸಿ.\n4. ಲೆಕ್ಕಹಾಕಿ ಕ್ಲಿಕ್ ಮಾಡಿ.',
        'developed_by': 'BitByBit ಅಭಿವೃದ್ಧಿ ಮಾಡಿದ',
        'upload_image': 'ಚಿತ್ರವನ್ನು ಅಪ್ಲೋಡ್ ಮಾಡಿ',
        'enter_product': 'ಉತ್ಪನ್ನದ ಹೆಸರು ನಮೂದಿಸಿ',
        'enter_quantity': 'ಪ್ರಮಾಣವನ್ನು ನಮೂದಿಸಿ (ಕಿಲೋಗ್ರಾಂ)',
        'calculate_button': 'ಕ್ಯಾಲ್ಕುಲೇಟು',
        'water_footprint': '{} ಕಿಲೋಗ್ರಾಂ {} ಗೆ ನೀರಿನ ಪಾದಚಾರಕ: {} ಲೀಟರ್',
        'not_found': 'ಡೇಟಾಬೇಸ್ನಲ್ಲಿ ಉತ್ಪನ್ನವು ಕಾಣಸಿಗುತ್ತಿಲ್ಲ. ದಯವಿಟ್ಟು ಮಾನ್ಯವಾದ ಉತ್ಪನ್ನವನ್ನು ನಮೂದಿಸಿ.',
        'select_language': 'ಭಾಷೆ ಆಯ್ಕೆಮಾಡಿ'
    },
    'Telugu': {
        'app_title': 'నీరు ఫుట్‌ప్రింట్ కాల్క్యులేటర్',
        'app_description': 'నీరు ఫుట్‌ప్రింట్ కాల్క్యులేటర్ వివిధ వ్యవసాయ మరియు తుది ఉత్పత్తుల కోసం నీటి పాదచారాన్ని అంచనా వేయడంలో సహాయపడుతుంది.',
        'features': 'ఫీచర్లు:\n- ముడి ఉత్పత్తుల కోసం నీటి పాదచారాన్ని లెక్కించండి: పంట రకం మరియు పరిమాణం నమోదు చేయండి.\n- తుది ఉత్పత్తుల కోసం నీటి పాదచారాన్ని లెక్కించండి: తుది ఉత్పత్తి మరియు పరిమాణాన్ని నమోదు చేయండి.\n- చిత్రంను ఉపయోగించి పండ్లు/కూరగాయలను గుర్తించండి: పండు లేదా కూరగాయను గుర్తించడానికి చిత్రం అప్లోడ్ చేయండి.',
        'calculate_raw_products': 'ముడి ఉత్పత్తుల కోసం నీటి పాదచారాన్ని లెక్కించండి: గోధుమ, అన్నం, మక్క, సోయా బీన్స్',
        'calculate_final_products': 'తుది ఉత్పత్తుల కోసం నీటి పాదచారాన్ని లెక్కించండి: బాటిల్ చేయబడిన నారింజ రస, ఉడికించిన అన్నం, స్టీమ్డ్ టమాటా, క్యాన్డ్ బీన్స్',
        'detect_image': 'చిత్రంను ఉపయోగించి పండ్లు/కూరగాయలను గుర్తించండి',
        'supported_products': 'మద్దతు అందించే ఉత్పత్తులు:\nముడి ఉత్పత్తులు: గోధుమ, అన్నం, మక్క, సోయా బీన్స్\nతుది ఉత్పత్తులు: బాటిల్ చేయబడిన నారింజ రస, ఉడికించిన అన్నం, స్టీమ్డ్ టమాటా, క్యాన్డ్ బీన్స్',
        'how_to_use': 'ఉపయోగించడానికి ఎలా:\n1. ఉత్పత్తి రకం ఎంచుకోండి: ముడి లేదా తుది.\n2. ఇన్పుట్ పద్ధతిని ఎంచుకోండి: చిత్రం లేదా మాన్యువల్.\n3. చిత్రం అప్లోడ్ చేయండి (ఎంపికయై) లేదా ఉత్పత్తి పేరు నమోదు చేయండి.\n4. లెక్కించు పై క్లిక్ చేయండి.',
        'developed_by': 'BitByBit అభివృద్ధి చేసినది',
        'upload_image': 'చిత్రం అప్లోడ్ చేయండి',
        'enter_product': 'ఉత్పత్తి పేరు నమోదు చేయండి',
        'enter_quantity': 'ప్రమాణం నమోదు చేయండి (కిలోగ్రాములు)',
        'calculate_button': 'లెక్కించు',
        'water_footprint': '{} కిలోగ్రాముల {} కోసం నీటి పాదచార: {} లీటర్లు',
        'not_found': 'డేటాబేస్‌లో ఉత్పత్తి కనుగొనబడలేదు. దయచేసి సరైన ఉత్పత్తి పేరు నమోదు చేయండి.',
        'select_language': 'భాషను ఎంచుకోండి'
    },
    'Tamil': {
        'app_title': 'தண்ணீர் பாதிப்புச் கணக்கீட்டாளர்',
        'app_description': 'தண்ணீர் பாதிப்புச் கணக்கீட்டாளர் பல்வேறு வேளாண்மையும் இறுதி தயாரிப்புகளுக்கும் நீர் பாதிப்பைக் கணிக்க உதவுகிறது.',
        'features': 'விசேஷங்கள்:\n- முதன்மை தயாரிப்புகளுக்கான நீர் பாதிப்பைக் கணக்கிடுங்கள்: பயிர் வகை மற்றும் அளவை உள்ளிடவும்.\n- இறுதி தயாரிப்புகளுக்கான நீர் பாதிப்பைக் கணக்கிடுங்கள்: இறுதி தயாரிப்பு மற்றும் அளவை உள்ளிடவும்.\n- படத்தைப் பயன்படுத்தி பழங்கள்/காய்கறிகளை அடையாளம் காணுங்கள்: பழம் அல்லது காய்கறியை அடையாளம் காண படத்தைப் பதிவேற்றவும்.',
        'calculate_raw_products': 'முதன்மை தயாரிப்புகளுக்கான நீர் பாதிப்பைக் கணக்கிடுங்கள்: கோதுமை, அரிசி, மக்கா, சோயா பீன்ஸ்',
        'calculate_final_products': 'இறுதி தயாரிப்புகளுக்கான நீர் பாதிப்பைக் கணக்கிடுங்கள்: பாட்டில் செய்யப்பட்ட நாரிஞ்சியரசு, சமைத்த அரிசி, ஆவியிலான தக்காளி, கேன் செய்யப்பட்ட பீன்கள்',
        'detect_image': 'படத்தைப் பயன்படுத்தி பழங்கள்/காய்கறிகளை அடையாளம் காணுங்கள்',
        'supported_products': 'ஆதரிக்கக்கூடிய தயாரிப்புகள்:\nமுதன்மை தயாரிப்புகள்: கோதுமை, அரிசி, மக்கா, சோயா பீன்ஸ்\nஇறுதி தயாரிப்புகள்: பாட்டில் செய்யப்பட்ட நாரிஞ்சியரசு, சமைத்த அரிசி, ஆவியிலான தக்காளி, கேன் செய்யப்பட்ட பீன்கள்',
        'how_to_use': 'எப்படி பயன்படுத்துவது:\n1. தயாரிப்பு வகையைத் தேர்ந்தெடுக்கவும்: முதன்மை அல்லது இறுதி.\n2. உள்ளீட்டு முறையைத் தேர்ந்தெடுக்கவும்: படம் அல்லது கையேடு.\n3. படம் பதிவேற்றவும் (தேர்வாக) அல்லது தயாரிப்பு பெயரை உள்ளிடவும்.\n4. கணக்கிட பட்டனை கிளிக் செய்யவும்.',
        'developed_by': 'BitByBit உருவாக்கப்பட்டது',
        'upload_image': 'படத்தைப் பதிவேற்றவும்',
        'enter_product': 'தயாரிப்பு பெயரை உள்ளிடவும்',
        'enter_quantity': 'அளவைக் கணக்கிடவும் (கிலோ)',
        'calculate_button': 'கணக்கீடு',
        'water_footprint': '{} கிலோ {} க்கான நீர் பாதிப்பு: {} லிட்டர்கள்',
        'not_found': 'தரவுருவில் தயாரிப்பு காணப்படவில்லை. தயவுசெய்து ஒரு செல்லுபடியான தயாரிப்பு பெயரை உள்ளிடவும்.',
        'select_language': 'மொழியைத் தேர்ந்தெடுக்கவும்'
    }
}

# Load YOLOv5 model
model = torch.hub.load('ultralytics/yolov5', 'yolov5s', pretrained=True)

# Detect fruits/vegetables from image using YOLOv5
def detect_fruit_vegetable(image):
    image_array = np.array(image)
    results = model(image_array)
    detected_classes = results.names
    detected = [detected_classes[int(x)] for x in results.xyxy[0][:, -1]]
    return detected

# Streamlit app
def main():
    st.sidebar.title(translations[st.session_state.language]['app_title'])
    st.sidebar.subheader(translations[st.session_state.language]['app_description'])
    st.sidebar.text(translations[st.session_state.language]['features'])
    st.sidebar.text(translations[st.session_state.language]['how_to_use'])
    st.sidebar.text(translations[st.session_state.language]['developed_by'])
    
    # Language selection
    st.sidebar.subheader(translations[st.session_state.language]['select_language'])
    language = st.sidebar.selectbox(
        translations[st.session_state.language]['select_language'],
        ['English', 'Hindi', 'Kannada', 'Telugu', 'Tamil']
    )
    st.session_state.language = language

    st.title(translations[st.session_state.language]['app_title'])
    
    option = st.selectbox(
        translations[st.session_state.language]['calculate_raw_products'],
        ['Select Input Method', 'Image', 'Manual Input']
    )
    
    if option == 'Image':
        st.subheader(translations[st.session_state.language]['detect_image'])
        uploaded_image = st.file_uploader(translations[st.session_state.language]['upload_image'], type=['jpg', 'png', 'jpeg'])
        if uploaded_image:
            image = Image.open(uploaded_image)
            detected_items = detect_fruit_vegetable(image)
            st.write(f"Detected items: {', '.join(detected_items)}")
            selected_item = st.selectbox('Select detected item', detected_items + ['None'])
            if selected_item and selected_item in water_footprint_db:
                quantity = st.number_input(translations[st.session_state.language]['enter_quantity'], min_value=0)
                if st.button(translations[st.session_state.language]['calculate_button']):
                    footprint = quantity * water_footprint_db[selected_item]
                    st.write(translations[st.session_state.language]['water_footprint'].format(quantity, selected_item, footprint))
            else:
                st.write(translations[st.session_state.language]['not_found'])
                
    elif option == 'Manual Input':
        st.subheader(translations[st.session_state.language]['calculate_final_products'])
        product = st.selectbox(translations[st.session_state.language]['enter_product'], list(water_footprint_db.keys()))
        quantity = st.number_input(translations[st.session_state.language]['enter_quantity'], min_value=0)
        if st.button(translations[st.session_state.language]['calculate_button']):
            if product in water_footprint_db:
                footprint = quantity * water_footprint_db[product]
                st.write(translations[st.session_state.language]['water_footprint'].format(quantity, product, footprint))
            else:
                st.write(translations[st.session_state.language]['not_found'])

if __name__ == '__main__':
    if 'language' not in st.session_state:
        st.session_state.language = 'English'
    main()
